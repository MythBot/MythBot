# Mammoth
Wanna Join Discord Server?
"https://discord.gg/3etcSXF" 

Invite Mammoth To Your Server?
https://discordapp.com/oauth2/authorize?client_id=434028605131980812&scope=bot&permissions=2146958591
